//package com.xsh.mailtest;
//
//import com.xsh.customer.SmsCustomer;
//import org.junit.Test;
//import org.junit.runner.RunWith;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.test.context.junit4.SpringRunner;
//
///**
// * @author : xsh
// * @create : 2020-03-21 - 23:28
// * @describe: 发送短信测试
// */
//@RunWith(SpringRunner.class)
//@SpringBootTest
//public class SmsTest {
//
//    @Autowired
//    private SmsCustomer smsCustomer;
//
//    @Test
//    public void test(){
//        smsCustomer.sendVerifyCode("11111111111");
//    }
//
//}
