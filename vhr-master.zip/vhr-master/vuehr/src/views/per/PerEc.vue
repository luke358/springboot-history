<template>
    <div>
        PerEc
    </div>
</template>

<script>
    export default {
        name: "PerEc"
    }
</script>

<style scoped>

</style>