<template>
    <div>
        系统管理
    </div>
</template>

<script>
    export default {
        name: "SysCfg"
    }
</script>

<style scoped>

</style>